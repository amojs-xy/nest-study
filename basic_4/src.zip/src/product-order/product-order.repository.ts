import { Injectable } from "@nestjs/common";
import { readFileSync, writeFileSync } from "fs";
import { Product, ProductOrder } from "src/typing/product";

@Injectable()
export class ProductOrderRepository {
    public checkOrderInvalid (productId: string, quantity: number) {
       const productData = JSON.parse(readFileSync('../data/product.json', 'utf8'));
       
       const productInfo = productData.find((product: Product) => {
          if (product.id === productId) {
            if (product.remaining >= quantity) {
                return {
                    product,
                    quantity
                }
            }

            return {
                product,
                quantity: 0
            };
          }

          return {
            product: null,
            quantity: 0
        };
       });

       return productInfo;
    }

    public createOrder (productId: string, userId: string, quantity: number) {
        const order: ProductOrder = {
            id: new Date().getTime().toString(),
            productId,
            productName: '',
            userId,
            quantity,
            dateTime: new Date().getTime()
        }

        let productData = JSON.parse(readFileSync('../data/product.json', 'utf8'));

        productData = productData.map((p: Product) => {
            if (p.id === productId) {
               p.remaining -= quantity;
               order.productName = p.name;
            }
            return p;
        });

        writeFileSync('../data/product.json', JSON.stringify(productData));

        const productOrderData = JSON.parse(readFileSync('../data/product-order.json', 'utf8'));
        productOrderData.unshift(order);
        writeFileSync('../data/product.json', JSON.stringify(productOrderData));

        return order;
    }
}

